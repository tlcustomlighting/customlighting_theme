    </div>
    <footer class="text-center">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <table id="footer-contacts" class="text-center">
                    <tr>
                        <td>P: +1 310.622.7313</td>
                        <td>F: +1 310.300.4484</td>
                        <td>info@tlcustomlighting.com</td>
                    </tr>
                </table>
            </div>
            <div class="col-md-2"></div>
        </div>
        <h6>tL* Custom Lighting info@tlcustomlighting.com • +1.310.622.7313 © 2015. All Rights Reserved</h6>
        <?php wp_footer(); ?>
    </footer>
    <!-- Add JQuery and Bootstrap -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </body>
</html>