<?php
get_header();
?>

<div class="login-body">
    <h2 class="login-info">The login feature of this website is currently under construction. For questions and queries please refer to our contact methods below.</h2>
</div>

<?php
get_footer();
?>